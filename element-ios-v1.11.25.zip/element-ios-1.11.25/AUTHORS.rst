Guillaume Foret <giom at matrix.org>
 * Core developer
 
Emmanuel Rohee <manu at matrix.org>
 * Core developer
 
Yannick Le Collen <yannick at matrix.org>
 * Core developer
 
Dave Baker <dave at matrix.org>
 * General doc & housekeeping

Matthew Hodgson <matthew at matrix.org>
 * General doc & housekeeping
 * Fix Emoji keyboard crash.
 * RoomParticipantsViewController: search bar refactoring

Aaron Raimist <aaron at raim.ist>
 * Update the services supported by the app. 

Denis Morozov <dmorozkn at gmail.com>
 * Fix default room avatar for an empty room #1044
 * PR #1090, PR #1113, PR #1123: UX improvements
 * PR #1132: Check email validity during reset password operation
 * VoIP improvements
 
Aram Sargsyan <aram.sargsyan.1997 at gmail.com>
 * PR #1341: Read receipts details
 
Vivian Lim <vivvnlim at gmail.com>
 * PR #1513 Return key on hardware keyboards now sends messages

Dawid Rączka <dawidraczka at gmail.com>
 * PR #1729 Fixed keyboard color when entering bug report
 
Evan Tang <etang110 at gmail.com>
 * PR #1737 Cancel Buttons use style Cancel

Joey Watts <joey.watts.96 at gmail.com>
 * PR #1777 Add support for interactive notifications
 
Arash Tabrizian <a.tabriziyan at gmail.com>
 * PR #1828 Fix issue #1793 Confirmation popup when leaving room
 * PR #1824 Fix issue #1816 Support specifying kick and ban msgs
 
Doug Earnshaw <pixlwave at users.noreply.github.com>
 * PR #1865 Fix timezone interval