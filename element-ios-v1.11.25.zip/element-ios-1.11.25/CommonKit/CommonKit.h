// 
// Copyright 2021-2024 New Vector Ltd.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
// Please see LICENSE files in the repository root for full details.
//

#import <Foundation/Foundation.h>

//! Project version number for CommonKit.
FOUNDATION_EXPORT double CommonKitVersionNumber;

//! Project version string for CommonKit.
FOUNDATION_EXPORT const unsigned char CommonKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CommonKit/PublicHeader.h>


